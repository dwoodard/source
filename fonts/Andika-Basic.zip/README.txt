README - Andika Basic Regular Release 1.0 2 May 2008
===========================================================

Thank you for your interest in Andika ("Write!" in Swahili), a Unicode-compliant sans serif font designed by SIL International primarily for literacy use.

See FONTLOG.txt for detailed information on the rationale for Andika, as well as a complete list of supported characters.

See AndikaBasicR-FAQ-KI.txt for frequently-asked questions and known issues.

See OFL.txt for the complete text of the SIL Open Font License. See OFL-FAQ.txt for frequently-asked questions about the SIL Open Font License.

There is one TrueType (.ttf) font file included:
   AndBasR.ttf


INSTALLATION
=============
In Windows XP:
-->Right click on Start icon in Taskbar, choose Explore, navigate to downloaded font file (AndBasR.ttf; wherever you unzipped it to). On Folders side of window, go to Local Disk (C:)/Windows/, and drag font files into Fonts folder.


CONTACT
========
For more information please visit the Andika page on SIL International's Computers and Writing Systems website at http://scripts.sil.org/Andika. Or send an e-mail to <andika AT sil DOT org>.